#!/bin/sh
echo "#define OPENSMILE_SOURCE_REVISION \"2014:2043\"" > src/include/core/svn_version.hpp
echo "#define OPENSMILE_BUILD_DATE \"Fri Oct 28 21:16:39 CEST 2016\"" >> src/include/core/svn_version.hpp
echo "#define OPENSMILE_BUILD_BRANCH \"opensmile-2.3.0\"" >> src/include/core/svn_version.hpp
